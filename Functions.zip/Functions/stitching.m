
function [post_stiching_final]=stitching(sorted_tiles,tile_parameters)
z_plane_number=tile_parameters.z_plane_number;
all_row=tile_parameters.all_row;
imsize=tile_parameters.imsize;
num_rows=tile_parameters.num_rows;
num_column=tile_parameters.num_column;
total_tile_number=tile_parameters.total_tile_number;
shift_in_each_row=tile_parameters.shift_in_each_row;
shift_between_rows=tile_parameters.shift_between_rows;


overlaping=ceil(imsize*0.1);

% adjusting the shifting parameters so sthat the 1st image in each row is
% not croped.
% index_of_1st_each_row=all_row*num_column;
% shift_in_each_row(index_of_1st_each_row,:)=0;
% shift_in_each_row(index_of_1st_each_row,4)=overlaping-1;
% shift_in_each_row=cat(1, shift_in_each_row(end,:),shift_in_each_row);
post_stitching=[];
post_stitching_row=cell(num_rows,1);


for i=1:total_tile_number
    shift_y=shift_in_each_row(i,3,z_plane_number);
    % y is vertical direction;
    shift_x=overlaping-(shift_in_each_row(i,4,z_plane_number));
    % x is horizontal direction;
    if i==1
        shifted_y=imtranslate(sorted_tiles{i,z_plane_number},[0,shift_y]);
        croped_x=shifted_y(:,shift_x:end);
        post_stitching=cat(2,post_stitching,croped_x);
    elseif i>=2 && mod(i,num_column)~=1
        shift_y=shift_y+shift_in_each_row(i-1,3,z_plane_number);
        % the shift in y in the >=2 image need to accumulate previous
        % y shift as well.
        shifted_y=imtranslate(sorted_tiles{i,z_plane_number},[0,shift_y]);
        croped_x=shifted_y(:,shift_x:end);
        post_stitching=cat(2,post_stitching,croped_x);
    else
        % this is to restart the next row;
        post_stitching_row{(i-1)/num_column,1}=post_stitching;
        post_stitching=[];
        shifted_y=imtranslate(sorted_tiles{i,z_plane_number},[0,shift_y]);
        croped_x=shifted_y(:,shift_x:end);
        post_stitching=cat(2,post_stitching,croped_x);
    end
    
end
post_stitching_row{i/num_column,1}=post_stitching;


%once the image in each row is stitched, the next is to stitch them
% verically into a whole image, there are 3 row here; the shift is
% calculated by the overlapping reagion between each entire row;
row_pix_length=zeros(num_rows,1);

for row=1:num_rows
    row_pix_length(row)=size(post_stitching_row{row},2);
end
shortest_row=min(row_pix_length);

for row=1:num_rows
    
    if size(post_stitching_row{row,1},2)>shortest_row
        post_stitching_row{row,1}(:,(shortest_row+1):end)=[];
    elseif  size(post_stitching_row{row,1},2)<shortest_row
        post_stitching_row{row,1}= cat(2, post_stitching_row{row,1},...
            zeros(im_size,shortest_row-size(post_stitching_row{row,1},2)));
    end
end

%
% the above is to make sure each row has the same image size.

% the follwoing use dftregistration to directly calculate the difrt in row
% 2 and row 3.

row_ver_shift=0;
row_hor_shift=0;
shifted_row=cell(num_rows,1);
post_stiching_final=[];

for row=1:num_rows-1
    
    row_ver_shift=overlaping-shift_between_rows(row,3,z_plane_number);
    row_hor_shift=shift_between_rows(row,4,z_plane_number)+row_hor_shift;
    shifted_row=imtranslate(post_stitching_row{row},[row_hor_shift,0]);
    croped_row=shifted_row(1:end-row_ver_shift,:);
    post_stiching_final=cat(1,post_stiching_final,croped_row);
end

post_stiching_final=cat(1,post_stiching_final,post_stitching_row{end});

end

