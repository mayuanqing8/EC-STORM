function [STORM_1,STORM_2,sup_final_channel_1,sup_final_channel_2,...
    STORM_im_size]=make_2_color_STORM_image_with_drift_correction_3D2()
[STORM]=open_text_table_for_3D_STORM2();
if uint16(max(STORM(:,3)))>30000
    im_dim=512;
else
    im_dim=256;
end
STORM(STORM(:,3)<=5,:)=[];
% get rid of the negative coordinated molecules

STORM_im_size=im_dim*10;
channel_1=STORM(:,10)==1;
channel_2=STORM(:,10)==2;

STORM_1=STORM(channel_1,1:9);
STORM_2=STORM(channel_2,1:9);

channel_1_X_Cors=STORM_1(:,3)/100;
channel_1_Y_Cors=STORM_1(:,4)/100;
channel_2_X_Cors=STORM_2(:,3)/100;
channel_2_Y_Cors=STORM_2(:,4)/100;

dx=1;
dy=1;
% this is PSF width; it should be equivalent to localization
% precision around 20 nm in the created final STORM image;

[X,Y] = meshgrid(-7:7); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
sz = [im_dim*10,im_dim*10];

Im = zeros(sz);
for i=1:numel(channel_1_X_Cors)
    Im(round(channel_1_Y_Cors(i)*10),round(channel_1_X_Cors(i)*10))=1;
    % the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');

% the final produced STORM image is 10x finner than the orignal image;
sup_final_channel_1=flipdim(sup_im,1); % flip the image from bottom up.
% sup_final=imresize(sup_im_rot,0.5);

Im = zeros(sz);
for i=1:numel(channel_2_X_Cors)
    Im(round(channel_2_Y_Cors(i)*10),round(channel_2_X_Cors(i)*10))=1;
    % the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');

% the final produced STORM image is 10x finner than the orignal image;
sup_final_channel_2=flipdim(sup_im,1); % flip the image from bottom up.
% sup_final=imresize(sup_im_rot,0.5);

fft_one=fft2(sup_final_channel_1);
fft_two=fft2(sup_final_channel_2);
[shift, ~] = dftregistration(fft_one,fft_two,10);
STORM_1(:,3)=STORM_1(:,3)-shift(4)*10;
STORM_1(:,4)=STORM_1(:,4)+shift(3)*10;

channel_1_X_Cors=STORM_1(:,3)/100;
channel_1_Y_Cors=STORM_1(:,4)/100;

Im = zeros(sz);
for i=1:numel(channel_1_X_Cors)
    Im(round(channel_1_Y_Cors(i)*10),round(channel_1_X_Cors(i)*10))=1;
end
sup_im=conv2(Im,fK,'same');
sup_final_channel_1=flipdim(sup_im,1);

figure (2)
c=imfuse(sup_final_channel_2,sup_final_channel_1,'ColorChannels','green-magenta');
imshow(c);
title('Magenta: channel-1    green: channel-2');

end

