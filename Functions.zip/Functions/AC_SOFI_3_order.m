function [acf]=AC_SOFI_3_order(X)
% X and Y need to be column vector; 
mean_X=mean(X);
deta_X=X-mean_X;
correlation_length=floor(length(X)/10);
acf=zeros(1,correlation_length);

for i=1:correlation_length
    n=numel(deta_X(1:end-(i+1)));
    acf(i)=sum(deta_X(1:end-(i+1)).* deta_X(i+1:end-1).* deta_X(i+2:end))/n; 
end
 acf(1)=acf(2);
 acf=acf./(mean_X)^3;

end

