
STORM=STORM_dift_corrected;

im_dim=256;

X_Cors=(STORM(:,3)/100);
Y_Cors=(STORM(:,4)/100);

dx=2; 
dy=2;
% this is PSF width; it should be equivalent to localization 
% precision around 20 nm in the created final STORM image;


[X,Y] = meshgrid(-10:10); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
% imagesc(fK);
% colormap gray
% colorbar
flat_top=ones(3);
sz = [im_dim*20,im_dim*20];
intensity_Im = zeros(sz);
z_color_Im=zeros(sz);

for i=1:numel(X_Cors)
intensity_Im(round(Y_Cors(i)*20),round(X_Cors(i)*20))=1; 
z_color_Im(round(Y_Cors(i)*20),round(X_Cors(i)*20))=circle_ratio(i); 
% the multiplification is to expand the image and reduce round off error.
end

sup_im=conv2(intensity_Im,fK,'same');
 sup_color_im=conv2(z_color_Im,flat_top,'same');

sup_im_rot=flipdim(sup_im,1); % flip the image from bottom up. 
sup_color_im_rot=flipdim(sup_color_im,1);

sup_final=imresize(sup_im_rot,0.5);
color_final=imresize(sup_color_im_rot,0.5);

smooth_color=smoothdata(color_final,'lowess',100);
smooth_color2=smoothdata(smooth_color','lowess',100);
smooth_color3=smooth_color2';

up=max(sup_final,[],[1 2]);
lo=min(sup_final,[],[1,2]);
sup_final(sup_final>up*0.99)=up*0.99;
sup_final(sup_final<up*0.02)=NaN;
smooth_color3(smooth_color3>-0.001  )=NaN;
smooth_color3(smooth_color3<-0.008 )=NaN;
HSV_map=imread('jet.png');
z_gradient=rescale(smooth_color3,1,1024);
int_grandient=rescale(sup_final,1,1024);
SOTMR_im_size=size((sup_final),1);
int_w_FLIM=zeros(SOTMR_im_size,SOTMR_im_size,3);

z_gradient(isnan(z_gradient))=1;
int_grandient(isnan(int_grandient))=1;


% FLIM_gradient(isnan(FLIM_gradient))=1;
% int_grandient(isnan(int_grandient))=1;

for i=1:SOTMR_im_size
    for j=1:SOTMR_im_size
    int_w_FLIM(i,j,:)=HSV_map(round(z_gradient(i,j)),round(int_grandient(i,j)*1),:);
    % the multiplication of 0.67 is to reduce the satuation level of the
    % intensity apsect of the image; 
    end
end

     image(int_w_FLIM*0.009);
     pbaspect([1,1,1]);
     