% the function open the Elyra exported text file and remove some 
% unncesssary data, it produce a matrix and sperate vector with names for
% each coloum. 
function[STORM,names]=open_txt_table()
[file path] = uigetfile('*.txt');
cd (path);
raw=importdata(file);
raw.data(:,[3,4,11,13])=[];
names=string(raw.textdata);
names([3,4,11,13])=[];
names(2)='frame detected';
STORM=raw.data;
end
