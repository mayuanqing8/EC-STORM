function [STORM_1,STORM_2,field_name,sup_final_channel_1,sup_final_channel_2]=make_2_color_STORM_image()
[STORM,field_name]=open_text_table();
if uint16(max(STORM(:,3)))>30000
    im_dim=512;
else
    im_dim=256;
end
channel_1=STORM(:,9)==1;
channel_2=STORM(:,9)==2;

STORM_1=STORM(channel_1,:);
STORM_2=STORM(channel_2,:);

channel_1_X_Cors=STORM_1(:,3)/100;
channel_1_Y_Cors=STORM_1(:,4)/100;
channel_2_X_Cors=STORM_2(:,3)/100;
channel_2_Y_Cors=STORM_2(:,4)/100;

dx=1; 
dy=1;
% this is PSF width; it should be equivalent to localization 
% precision around 20 nm in the created final STORM image;

[X,Y] = meshgrid(-7:7); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
% imagesc(fK);
% colormap gray
% colorbar
sz = [im_dim*10,im_dim*10];

Im = zeros(sz);
for i=1:numel(channel_1_X_Cors)
Im(round(channel_1_Y_Cors(i)*10),round(channel_1_X_Cors(i)*10))=1; 
% the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');

% the final produced STORM image is 10x finner than the orignal image;
sup_final_channel_1=flipdim(sup_im,1); % flip the image from bottom up. 
% sup_final=imresize(sup_im_rot,0.5);

Im = zeros(sz);
for i=1:numel(channel_2_X_Cors)
Im(round(channel_2_Y_Cors(i)*10),round(channel_2_X_Cors(i)*10))=1; 
% the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');

% the final produced STORM image is 10x finner than the orignal image;
sup_final_channel_2=flipdim(sup_im,1); % flip the image from bottom up. 
% sup_final=imresize(sup_im_rot,0.5);


figure (1)
c=imfuse(sup_final_channel_2,sup_final_channel_1,'ColorChannels','green-magenta');imshow(c);
title('red: channel_1    white: channel_2');

STORM_1=STORM(channel_1,:);
STORM_2=STORM(channel_2,:);


end

