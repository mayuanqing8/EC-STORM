% this function plot the single molecule trigectory exported result, it
% will make histograms for the total ontime, total offtime, average ontime
% anzlyed by thresholding and averge ontime analyzed by correlation
% analysis.
function plot_result(track_file,n)
 total_ontime=1;
 total_offtime=2;
 blink_times=3;
 average_ontime=4;
 correlation_time=5;
 
 all_total_ontime=[table2array(track_file{n,1}(:,total_ontime));table2array(track_file{n+1,1}(:,total_ontime));...
     table2array(track_file{n+2,1}(:,total_ontime))];
 all_total_offtime=[table2array(track_file{n,1}(:,total_offtime));table2array(track_file{n+1,1}(:,total_offtime));...
     table2array(track_file{n+2,1}(:,total_offtime))];
 all_blink_times=[table2array(track_file{n,1}(:,blink_times));table2array(track_file{n+1,1}(:,blink_times));...
     table2array(track_file{n+2,1}(:,blink_times))];
all_averge_ontime=[table2array(track_file{n,1}(:,average_ontime));table2array(track_file{n+1,1}(:,average_ontime));...
     table2array(track_file{n+2,1}(:,average_ontime))];
all_correlation_time=[table2array(track_file{n,1}(:,correlation_time));table2array(track_file{n+1,1}(:,correlation_time));...
     table2array(track_file{n+2,1}(:,correlation_time))];

 % try to fit the histogram
 subplot(3,2,1)
[total_on,edge]=histcounts(all_total_ontime);
x_axis=linspace(edge(1),edge(end),length(total_on));
[f_totoal_on,gof_totoal_on]=fit(x_axis',total_on','gauss1');
histogram(all_total_ontime);
hold on
plot(f_totoal_on,x_axis,total_on);
hold off
title('total on time');
xlabel('time (s)');
ylabel('frequency');


subplot(3,2,2)
[total_off,edge]=histcounts(all_total_offtime);
x_axis=linspace(edge(1),edge(end),length(total_off));
[f_total_off,gof_total_off]=fit(x_axis',total_off','gauss1');
histogram(all_total_offtime);
hold on
plot(f_total_off,x_axis,total_off);
hold off
title('total off time');
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,3)
[ave_on,edge]=histcounts(all_averge_ontime);
x_axis=linspace(edge(1),edge(end),length(ave_on));
[f_ave_on,gof_ave_on]=fit(x_axis',ave_on','exp1','Exclude',x_axis<2);
histogram(all_averge_ontime);
hold on
plot(f_ave_on,x_axis,ave_on);
hold off
title('average on time');
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,4)
[cor_time,edge]=histcounts(all_correlation_time);
x_axis=linspace(edge(1),edge(end),length(cor_time));
[f_cor_time,gof_cor_time]=fit(x_axis',cor_time','exp1','Exclude',x_axis<2);
histogram(all_correlation_time);
hold on
plot(f_cor_time,x_axis,cor_time);
hold off
title('correlation');
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,5)
[blink,edge]=histcounts(all_blink_times);
x_axis=linspace(edge(1),edge(end),length(blink));
[f_blink,gof_blink]=fit(x_axis',blink','gauss1');
histogram(all_blink_times);
hold on
plot(f_blink,x_axis,blink);
hold off
title('number of blinks');
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,6)
goodness_of_fit=[gof_totoal_on.adjrsquare,gof_total_off.adjrsquare,gof_ave_on.adjrsquare, ...
    gof_cor_time.adjrsquare,gof_blink.adjrsquare];
bar(goodness_of_fit);
ylim([0.9, 1.04]);
title('goodness of fit');
end



