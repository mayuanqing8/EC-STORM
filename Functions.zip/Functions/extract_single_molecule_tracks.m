% this funtion produce the intensity time trace from idenfied molecules;
% it requires user to provide: 1,the thurderstorm table produced
% from single slide that made by the summed time stack of the zeiss movie, 
% 2, the acutuall unprocessed zeiss movie itself. 

function [bright_molecules,filename]=extract_single_molecule_tracks()
display ('open the thunderstorm analyzed excel table')
[position,~,filename]=open_excel_table_from_thunderSTORM;

display ('open the corresponding raw zeiss czi file')

hearder_movie=bfopen('cop.czi');
movie=hearder_movie{1}(:,1);
im_high=size(movie{1,1},1);
im_width=size(movie{1,1},2);
position(:,[3,4])=round(position(:,[3,4])/100);
% the 100 is the pixel size that used in the camera setup in ThunderStorm,
% previous, it was set to 1, but now it is set to 100 nm.

edge=2;
ROIs_int=zeros(length(movie),length(position));
i=1;
j=1;
 weight=[0 0 0.2 0 0; 0 0.4 0.6 0.4 0; 0.2 0.6 1 0.6 0.2; 0 0.4 0.6 0.4 0; 0 0 0.2 0 0];

while i<=length(position)
    if (position(i,3)-edge)>=1 &&(position(i,3)+ edge) <= im_high &&(position(i,4)-edge)>=1 && (position(i,4)+ edge) <= im_high
        for j=1:length(movie)
            frame=movie{j};
            ROI=frame((position(i,4)-edge):(position(i,4)+ edge),(position(i,3)-edge):(position(i,3)+ edge));
            ROI=double(ROI);
            ROI_weight=ROI.* weight;
            ROIs_int(j,i)=sum(ROI_weight,[1, 2]);
        end
        i=i+1;
    else
        i=i+1;
        
    end
end


bright_molecules=ROIs_int;

end


