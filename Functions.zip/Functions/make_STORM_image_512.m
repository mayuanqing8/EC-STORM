function [storm_table,field_name,sup_final]=make_STORM_image_512()
[STORM,name]=open_text_table();
storm_table=STORM;
field_name=name;
im_dim=512;

X_Cors=(STORM(:,3)/100);
Y_Cors=(STORM(:,4)/100);

dx=2; 
dy=2;
% this is PSF width; it should be equivalent to localization 
% precision around 20 nm in the created final STORM image;


[X,Y] = meshgrid(-10:10); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
imagesc(fK);
colormap gray
colorbar

sz = [im_dim*20,im_dim*20];
Im = zeros(sz);


for i=1:numel(X_Cors)
Im(round(Y_Cors(i)*20),round(X_Cors(i)*20))=1; 
% the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');



sup_im_rot=flipdim(sup_im,1); % flip the image from bottom up. 
sup_final=imresize(sup_im_rot,0.5);


figure
imagesc(sup_final);
axis square;
colormap gray;
colorbar;
caxis([0 0.2]);
end

