function [acf]=AC_SOFI_4_order(X)
% X and Y need to be column vector; 
mean_X=mean(X);
deta_X=X-mean_X;
correlation_length=floor(length(X)/10);
acf=zeros(1,correlation_length);

for i=1:correlation_length
    n_2=numel(deta_X(1:end-i));
    n_4=numel(deta_X(1:end-(i+2)));
    acf(i)=sum(deta_X(1:end-(i+2)).* deta_X(i+1:end-2).* deta_X(i+2:end-1).*deta_X(i+3:end))/n_4...
        -3*((deta_X(1:end-i)' * deta_X(i+1:end))/n_2)^2; 
end
 acf(1)=acf(2);
 acf=acf./(mean_X)^4;

end

