function [STORM,field_name,sup_final,pixel_size,im_dim]=make_STORM_image()
[STORM,field_name]=open_text_table();
if uint16(max(STORM(:,3)))>40000 && uint16(max(STORM(:,3)))<50000
    im_dim=512;
    pixel_size=100;
elseif  uint16(max(STORM(:,3)))>50000
    im_dim=512;
    pixel_size=160;
elseif uint16(max(STORM(:,3)))>30000 && uint16(max(STORM(:,3)))<40000
    im_dim=256;
    pixel_size=160;
else
        im_dim=256;
    pixel_size=100;
end


X_Cors=(STORM(:,3)/pixel_size);
Y_Cors=(STORM(:,4)/pixel_size);
dx=1; 
dy=1;
% this is PSF width; it should be equivalent to localization 
% precision around 20 nm in the created final STORM image;

[X,Y] = meshgrid(-7:7); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
% imagesc(fK);
% colormap gray
% colorbar
sz = [im_dim*20,im_dim*20];
Im = zeros(sz);

for i=1:numel(X_Cors)
Im(round(Y_Cors(i)*20),round(X_Cors(i)*20))=1; 
% the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');

% the final produced STORM image is 10x finner than the orignal image;
sup_final=flipdim(sup_im,1); % flip the image from bottom up. 
% sup_final=imresize(sup_im_rot,0.5);

display_STORM_iamge=figure (1);
set(display_STORM_iamge,'position',[450,0,850,850]);
imagesc(sup_final);
% xlim([0,5000]);
% ylim([0,5000]);
axis square;
colormap hot;
colorbar;
caxis([0 1]);
end

