function [storm_table,field_name,sup_final]=make_STORM_image_same_size()
[STORM,name]=open_text_table();
storm_table=STORM;
field_name=name;
if uint16(max(STORM(:,3)))>30000
    im_dim=512;
else
    im_dim=256;
end

X_Cors=(STORM(:,3)/100);
Y_Cors=(STORM(:,4)/100);

dx=1; 
dy=1;
% this is PSF width; it should be equivalent to localization 
% precision around 20 nm in the created final STORM image;


[X,Y] = meshgrid(-7:7); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
% imagesc(fK);
% colormap gray
% colorbar

sz = [im_dim,im_dim];
Im = zeros(sz);


for i=1:numel(X_Cors)
Im(round(Y_Cors(i)),round(X_Cors(i)))=1; 
% the multiplification is to expand the image and reduce round off error.
end
sup_im=conv2(Im,fK,'same');


% the final produced STORM image is 10x finner than the orignal image;
sup_final=flipdim(sup_im,1); % flip the image from bottom up. 
% sup_final=imresize(sup_im_rot,0.5);


figure
imagesc(sup_final);
axis square;
colormap turbo;
colorbar;
caxis([0 0.5]);
end

