function make_image(a)
name=inputname(1);

figure

scatter(a(:,3),a(:,4),0.5,'w','.')

set(gca,'color','k');

pbaspect([1 1 1]);

new_name=[name,'_STORM_image.fig'];

savefig(new_name);

end
