%% open the thurderstorm talbe and corresponding zeiss czi files;
all_molecules=extract_single_molecule_tracks;
[bright_molecules,bright_molecule_acf]=find_molecules_by_acf(all_molecules);
ontime=zeros(numel(bright_molecules(1,:)),1);
offtime=zeros(numel(bright_molecules(1,:)),1);
blink_times=zeros(numel(bright_molecules(1,:)),1);
cor_lag_time=linspace(1,30,333);
% extract the on and off time by mean;
for i=1:numel(bright_molecules(1,:))
bc=smoothdata(bright_molecules(:,i),'gaussian',50);
on=bc>mean(bc);
ontime(i)=sum(on);
offtime(i)=1000-ontime(i);
blink_times(i)=sum(diff(on)==1);


% subplot(3,1,1)
% plot(bc,'r');
% hold on
% plot(bright_molecules(:,i),'g');
% plot(on*(max(bright_molecules(:,i))-min(bright_molecules(:,i)))*0.5+median(bc),'k');
% hold off
% 
% subplot(3,1,2)
% histogram(bc,100);
% set(gca,'yscale','linear');
% pbaspect([2,1,1]);
% 
% subplot(3,1,3)
% semilogx(cor_lag_time,bright_molecule_acf(:,i),'*k-');
% pbaspect([2,1,1]);
% ylim([-0.1,1.1]);
% xlabel('lag time')
% pause(0.6)
end
% plot the on and off times

ontime=ontime.*0.06;
offtime=offtime.*0.06;
% 
% figure ('name','ontime')
% histogram(ontime,20);
% 
% figure ('name','offtime')
% histogram(offtime,20);
% 
% figure ('name','blink_times')
% histogram(blink_times,10);
% plot correlation result

correlation_time=zeros(numel(bright_molecule_acf(1,:)),1);

for i=1:numel(bright_molecule_acf(1,:))

smoothed_acf=csaps(cor_lag_time',bright_molecule_acf(:,i),0.05);
temp_curve=fnplt(smoothed_acf);
curve=temp_curve(2,:);
x_axis=temp_curve(1,:);

% plot(cor_lag_time,bright_molecule_acf(:,i),'*k');
% hold on
% plot(x_axis,curve);
% hold off
% pause(0.5);

G0=mean(curve(1:5));
offset=mean(curve(end-10:end));
half_amp=(G0-offset)/2;
lagtime_at_half_amp=knnsearch(bright_molecule_acf(:,i),half_amp,'K',1);
correlation_time(i)=cor_lag_time(lagtime_at_half_amp);

end
% 
% figure ('name', 'correlation time')
% histogram(correlation_time,30);




% save all the extracted data

all_data.ontime=ontime;
all_data.offtime=offtime;
all_data.blink_times=blink_times;
all_data.correlation_time=correlation_time;


% all_data=[ontime,offtime,blink_times,correlation_time];
% csvwrite('0.5 v 3.txt',all_data);

writetable(struct2table(all_data),'-0.1v 0.4v 34hz 3.txt');


