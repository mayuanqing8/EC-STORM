function [good_molecules,good_molecule_acf] = find_molecules_by_acf(all_molecules)
temp2=size(all_molecules);
number_of_molecules=temp2(2);
all_molecule_acf=zeros(332,number_of_molecules);

for i=1:number_of_molecules
    all_molecule_acf(:,i)=linear_correlation(all_molecules(:,i));
end

acf_amp=mean(all_molecule_acf([1:3],:));
good_molecule_acf=all_molecule_acf(:,acf_amp>0.5e-4);
good_molecules=all_molecules(:,acf_amp>0.5e-4);
end
