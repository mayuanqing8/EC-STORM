function [loaded_file]=load_tiff_file_by_name(file_name)
Tif_Link_red=Tiff(file_name,'r');
imageinfor=imfinfo(file_name);
frame_number=length(imageinfor);
frame_size=imageinfor(1).Width;
loaded_file=zeros(frame_size,frame_size,frame_number);
for i=1:frame_number
     Tif_Link_red.setDirectory(i);
     loaded_file(:,:,i)=Tif_Link_red.read();
end
Tif_Link_red.close();
end
