% the function open the imageJ exported excel file and remove some 
% unncesssary data, it produce a matrix and sperate vector with names for
% each coloum. 
function[STORM,names,filename]=open_PALM_table_from_Elyra7()
[filename, path] = uigetfile('*.csv');
cd (path);
raw=importdata(filename);
raw.data(:,[3,4,11,13])=[];
names=string(raw.textdata);
names([3,4,11,13])=[];
names(2)='frame detected';
STORM=raw.data;
filename=filename(1:end-4);
end
