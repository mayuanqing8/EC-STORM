function [storm_table,name_A,name_B]=make_2_STORM_image()
[STORM,name,file_name]=open_text_file_take_file_name();
storm_table=STORM;
field_name=name;
im_dim=256;

index_com=rand(numel(storm_table(:,1)),1);
index_A=index_com>0.5;
index_B=index_com<0.5;
X_Cors=(STORM(:,3)/100);
Y_Cors=(STORM(:,4)/100);

X_Cors_A=X_Cors(index_A);
Y_Cors_A=Y_Cors(index_A);

X_Cors_B=X_Cors(index_B);
Y_Cors_B=Y_Cors(index_B);


dx=2;
dy=2;
% this is PSF width; it should be equivalent to localization
% precision around 20 nm in the created final STORM image;


[X,Y] = meshgrid(-10:10); % overall PSF size;
fK = exp(-X.^2/dx^2-Y.^2/dy^2); % simulate PSF;
fK = fK/sum(fK(:));
imagesc(fK);
colormap gray
colorbar

sz = [im_dim*20,im_dim*20];
Im_A = zeros(sz);
Im_B= zeros(sz);


for i=1:numel(X_Cors_A)
    Im_A(round(Y_Cors_A(i)*20),round(X_Cors_A(i)*20))=1;
    % the multiplification is to expand the image and reduce round off error.
    
end
sup_im_A=conv2(Im_A,fK,'same');


for j=1:numel(X_Cors_B)
    Im_B(round(Y_Cors_B(j)*20),round(X_Cors_B(j)*20))=1;
end
sup_im_B=conv2(Im_B,fK,'same');

sup_im_rot_A=flipdim(sup_im_A,1); % flip the image from bottom up.
sup_final_A=imresize(sup_im_rot_A,0.5);
sup_im_rot_B=flipdim(sup_im_B,1); % flip the image from bottom up.
sup_final_B=imresize(sup_im_rot_B,0.5);

figure(1)
imagesc(sup_final_A);
axis square;
colormap gray;
colorbar;
caxis([0 0.5]);

figure(2)
imagesc(sup_final_B);
axis square;
colormap gray;
colorbar;
caxis([0 0.5]);

name_A=strcat(file_name,"A.tif");
name_B=strcat(file_name,"B.tif");
imwrite(sup_final_A,name_A);
imwrite(sup_final_B,name_B);

end

