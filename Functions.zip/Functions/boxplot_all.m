function boxplot_all(track_file)
temp=dir('*.txt');
file_number=length(temp);
aa=temp(1:3:file_number);
field={aa.name};
total_ontime=1;
blink_times=3;
average_ontime=4;
correlation_time=5;
m=1;

for n=1:3:file_number
all_total_ontime{m}=[table2array(track_file{n,1}(:,total_ontime));table2array(track_file{n+1,1}(:,total_ontime));...
     table2array(track_file{n+2,1}(:,total_ontime))];
all_averge_ontime{m}=[table2array(track_file{n,1}(:,average_ontime));table2array(track_file{n+1,1}(:,average_ontime));...
     table2array(track_file{n+2,1}(:,average_ontime))];
all_correlation_time{m}=[table2array(track_file{n,1}(:,correlation_time));table2array(track_file{n+1,1}(:,correlation_time));...
     table2array(track_file{n+2,1}(:,correlation_time))];
 all_blink_times{m}=[table2array(track_file{n,1}(:,blink_times));table2array(track_file{n+1,1}(:,blink_times));...
     table2array(track_file{n+2,1}(:,blink_times))];
 m=m+1;
end

subplot(2,2,1)
aa=padcell(all_total_ontime);
boxplot(aa,field);
title('total ontime');

subplot(2,2,2)
aa=padcell(all_averge_ontime);
boxplot(aa,field);
title('average on time');

subplot(2,2,3)
aa=padcell(all_correlation_time);
boxplot(aa,field);
% set(gca,'yscale','log');
title('correlation time');

subplot(2,2,4)
aa=padcell(all_blink_times);
boxplot(aa,field);
title('number of blinks');

end

function padded=padcell(X)
maxNumE = max(cellfun(@numel,X));
for s=1:numel(X)
    X{s}=padarray(X{s},maxNumE-numel(X{s}),NaN,'post');
end
padded=cell2mat(X);
end


