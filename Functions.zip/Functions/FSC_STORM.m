function  [FSC_final,frequency_range]=FSC_STORM(img1,img2)
dimension=length(img1(:,1));
pixel_size=10; % for 2nd order XC_SOFI; and 25 for 4 order SOFI
max_freq=2^nextpow2(dimension);
im1_fft =fft2(img1,max_freq,max_freq);
im2_fft=fft2(img2,max_freq,max_freq);
cent_ima1_fft=abs(fftshift(im1_fft));
cent_ima2_fft=abs(fftshift(im2_fft));
[columnsInImage, rowsInImage] = meshgrid(1:max_freq, 1:max_freq);
% Next create the circle in the image.
centerX = max_freq/2;
centerY = max_freq/2;
ring_number=70;
FSC_final=zeros(ring_number,1);
samp_frequency=(1/pixel_size)*(max_freq/dimension); 
% '*2' is to because when calculating fft, the image
% is padded upt to two thes size of original image;
lowest_frequency=1/(pixel_size*dimension);
frequency_range=linspace(lowest_frequency,samp_frequency/2,ring_number);
% here'samp_frequency/2' is because the fftshift cut off the high frequency
% stuff at half the maximal frequency;
ring_width=round((max_freq/2)/ring_number);
temp=zeros(max_freq);
temp(round((max_freq+1)/2)-3:round((max_freq+1)/2)+3,:)=1;
temp(:,round((max_freq+1)/2)-3:round((max_freq+1)/2)+3)=1;
fft_spike=temp;

for m=1:ring_number
    inner_circle = (-7+m*ring_width)*1.1;
    outer_circle=(m*ring_width)*1.1;
    % the 1.1 is a scaling factor for the ring so that the FSC of the last
    % ring should reach 0. this scaling factor need to be tested to set. 
    circlePixels = (rowsInImage - centerY).^2 ...
        + (columnsInImage - centerX).^2 <= outer_circle.^2 & (rowsInImage - centerY).^2 ...
        + (columnsInImage - centerX).^2 >= inner_circle.^2 ;
    % F_2R(m)=1/sqrt(sum(circlePixels,[1 2])/2);
    % circlePixels is a 2D "logical" array.
    % Now, display it.
%     imagesc(circlePixels) ;
%     axis square;
%     colormap gray;
%     colorbar;
%     caxis([0 0.8]);
%     pause(0.02);
    lin_A=cent_ima1_fft(:);
    lin_B=cent_ima2_fft(:);
    ring=find(circlePixels==1& fft_spike==0);
    
    delta_A=lin_A(ring)-mean(lin_A(ring));
    delta_B=lin_B(ring)-mean(lin_B(ring));
    n=numel(delta_A);
   
    FSC_final(m)=(delta_A'*delta_B)/sqrt(sum(delta_A.^2)*sum(delta_B.^2));
end

end

