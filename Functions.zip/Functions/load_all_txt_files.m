function [all_files]=load_all_txt_files()
temp=dir('*.txt');
all_files=cell(length(temp),2);
for i=1:length(temp)
    filename=temp(i).name;
    all_files{i,1}=readtable(filename);
    all_files{i,2}=temp(i).name;
end
end

