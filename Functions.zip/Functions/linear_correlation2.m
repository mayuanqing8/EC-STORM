function [acf]= linear_correlation2(X)
% X and Y need to be column vector; 
mean_X=mean(X);
deta_X=X-mean_X;
correlation_length=floor(length(X)/2);
acf=zeros(1,correlation_length);

for i=1:correlation_length
%     n=numel(deta_X(1:end-i));
    acf(i)=(deta_X(1:end-i)' * deta_X(i+1:end))...
        /sqrt(sum(deta_X(1:end-i).^2)*sum(deta_X(i+1:end).^2));  
 % normalization of acf should be acf(i)/sqrt(sum(deta_X(1:end-i).^2)*sum(deta_X(i+1:end)).^2)
end
 acf(1)=[];
% the above normalization by mean square is wrong;
end

