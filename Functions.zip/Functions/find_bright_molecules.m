function [bright_molecules]=find_bright_molecules(all_molecules)
temp=std(all_molecules);
temp1=mean(temp);
filter=temp>temp1;
bright_molecules=all_molecules(:,[filter]);


temp2=size(bright_molecules);
number_of_molecules=temp2(2);

for f=1:number_of_molecules
plot(bright_molecules(:,f),'-');
pbaspect([20,4,1]);
pause (0.2)

end


