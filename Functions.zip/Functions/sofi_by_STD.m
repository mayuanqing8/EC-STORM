function sofi=sofi_by_STD(data,cor_lev)
var1=zeros(512,512,numel(data(1,1,:)));

for j=1:numel(data(1,1,:))-cor_lev-1
       var1(:,:,j)= std(data(:,:,[j:(j+cor_lev)]),0,3);
end
sofi=var1;
end

