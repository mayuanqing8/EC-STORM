% here, the idea is to look at the gaps between the localization event of
% the molecules located at the same location, it could be just one
% molecule, or could be a cluster of molecules, where the function will
% trying to count the number of molecules inside the cluster. here, it is
% regarded that if the localization event is less than 100 frame appart,
% and it has counted more than 6 localization event with gaps between the
% event under 100 frame apart, it is regarded as event belongs to the same
% molecule, it is only when the localizaiton event are more then 100 frame
% apart, that it is most likely this are the localization event belong to a
% different dye;
function [blinking_times,count_event_per_molecule,molecule_counted]=count_molecules(molecule_index_list)
count_event_per_molecule=[];
position=[];
blinking_times=[];
list_of_gap_between_molecule=diff(molecule_index_list);
blinking_times=sum(list_of_gap_between_molecule>2);
% list_of_gap_between_molecule is the gaps bewteen the localization event;
aaaa=list_of_gap_between_molecule<100;
% aaas masks all the gaps under 100, so that only gaps more than 100 is 0,
% all the others is 1;
aaaa=cat(1,aaaa,0);
 b=1;
 event_count=0;
 molecule_counted=0;
 while b <= numel(aaaa)
   
     if aaaa(b)==1
         event_count=event_count+1;
         %here, any localization event under 100 frame
         %apart is binned  to one dye;
         b=b+1;
     else
         % by the time the condition come to else, it has encountered a 0,
         % where teh gaps between localization event is more than 100 frame
         % apart;
         if  event_count>6
             molecule_counted=molecule_counted+1;
             % here, if the localization event was contineous in frame and it count
             % more than 6, it is regarded as belong to one dye; because
             % by the time the loop come to this condition, it has come to
             % a gap with more than 100 frame in between;
             position(molecule_counted)=b;
             b=b+1;
             count_event_per_molecule(molecule_counted)=event_count;
             event_count=0;
         else
         
         b=b+1;
             
         end
     end
     
 end
end
