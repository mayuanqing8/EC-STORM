% this function plot the single molecule trigectory exported result, it
% will make histograms for the total ontime, total offtime, average ontime
% anzlyed by thresholding and averge ontime analyzed by correlation
% analysis.
% track_file is the cell structure contains all the combined text file of
% the single molecule trigectory analyzed on and off time kinetics data;
function histogram_fit_on_off_times(track_file,n)
 total_ontime=1;
 total_offtime=2;
 blink_times=3;
 average_ontime=4;
 correlation_time=5;
 
 all_total_ontime=[table2array(track_file{n,1}(:,total_ontime));table2array(track_file{n+1,1}(:,total_ontime));...
     table2array(track_file{n+2,1}(:,total_ontime))];
 all_total_offtime=[table2array(track_file{n,1}(:,total_offtime));table2array(track_file{n+1,1}(:,total_offtime));...
     table2array(track_file{n+2,1}(:,total_offtime))];
 all_blink_times=[table2array(track_file{n,1}(:,blink_times));table2array(track_file{n+1,1}(:,blink_times));...
     table2array(track_file{n+2,1}(:,blink_times))];
all_averge_ontime=[table2array(track_file{n,1}(:,average_ontime));table2array(track_file{n+1,1}(:,average_ontime));...
     table2array(track_file{n+2,1}(:,average_ontime))];
all_correlation_time=[table2array(track_file{n,1}(:,correlation_time));table2array(track_file{n+1,1}(:,correlation_time));...
     table2array(track_file{n+2,1}(:,correlation_time))];

 % try to fit the histogram
 subplot(3,2,1)
[total_on,edge]=histcounts(all_total_ontime);
x_axis=linspace(edge(1),edge(end),length(total_on));
[f_totoal_on,gof_totoal_on]=fit(x_axis',total_on','gauss1');
fit_par_ontime=coeffvalues(f_totoal_on);
fitted_ontime=fit_par_ontime(2);
histogram(all_total_ontime);
hold on
plot(f_totoal_on,x_axis,total_on);
hold off
title('total on time');
str=sprintf('Fitted total\n ontime is %4.2f',fitted_ontime);
text(1, 80, str);
xlabel('time (s)');
ylabel('frequency');


% subplot(3,2,2)
% [total_off,edge]=histcounts(all_total_offtime);
% x_axis=linspace(edge(1),edge(end),length(total_off));
% [f_total_off,gof_total_off]=fit(x_axis',total_off','gauss1');
% histogram(all_total_offtime);
% hold on
% plot(f_total_off,x_axis,total_off);
% hold off
% title('total off time');
% xlabel('time (s)');
% ylabel('frequency');

subplot(3,2,2)
[ave_on,edge]=histcounts(all_averge_ontime);
x_axis=linspace(edge(1),edge(end),length(ave_on));
[f_ave_on,gof_ave_on]=fit(x_axis',ave_on','exp1','Exclude',x_axis<2);
fit_par_ave_on=coeffvalues(f_ave_on);
tau_ave_on=-1/fit_par_ave_on(2);
histogram(all_averge_ontime);
hold on
plot(f_ave_on,x_axis,ave_on);
hold off
title('average on time');
str=sprintf('Fitted on time\n is %4.2f',tau_ave_on);
text(20, 100, str);
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,3)
[cor_time,edge]=histcounts(all_correlation_time);
x_axis=linspace(edge(1),edge(end),length(cor_time));
[f_cor_time,gof_cor_time]=fit(x_axis',cor_time','exp1','Exclude',x_axis<2);
fit_par_cor_time=coeffvalues(f_cor_time);
tau_cor_time=-1/fit_par_cor_time(2);
histogram(all_correlation_time);
hold on
plot(f_cor_time,x_axis,cor_time);
hold off
title('correlation');
str=sprintf('Fitted tau\n is %4.2f',tau_cor_time);
text(10, 100, str);
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,4)
[blink,edge]=histcounts(all_blink_times);
x_axis=linspace(edge(1),edge(end),length(blink));
[f_blink,gof_blink]=fit(x_axis',blink','exp1');
fit_par_blink=coeffvalues(f_blink);
blink_times=-1/fit_par_blink(2);
histogram(all_blink_times);
hold on
plot(f_blink,x_axis,blink);
hold off
title('number of blinks');
str=sprintf('number of blinks\n is %4.2f',blink_times);
text(6, 50, str);
xlabel('time (s)');
ylabel('frequency');

subplot(3,2,5)
goodness_of_fit=[gof_totoal_on.adjrsquare,gof_ave_on.adjrsquare, ...
    gof_cor_time.adjrsquare,gof_blink.adjrsquare];
bar(goodness_of_fit);
ylim([0.9, 1.04]);
title('goodness of fit');


subplot(3,2,6)
boxlabel={'total-ontime','Averge-ontime','correlation-time', 'blink-times'};
boxplot([all_total_ontime,all_averge_ontime,all_correlation_time, all_blink_times],boxlabel);

end



